<template>
    <div id="Articlelist">
       
    </div>
</template>
<script>
    //var bodyParser = require('body-parser')
    //var ueditor = require("ueditor")
    
    export default {
        name:'Articlelist',
        data () {
            return {
                add_url:'/mapi/article/addarticle',
            }
        },
        methods:{
            
        },
        components: {
          
        },
        mounted(){
            
        }
    }
</script>