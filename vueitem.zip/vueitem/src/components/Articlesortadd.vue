<template>
    <div id="container">
        <Row type="flex" justify="center">
            <Col span="10">
                <div id="title">
                    添加文章分类
                </div>
            </Col>
        </Row>
        <br>
        <Row type="flex" justify="center">
            <Col span="10">
            <div id="Input">
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    <span class="must">*</span>
                    分类名称：
                    </Col>
                    <Col span="18">
                    <Input type='text' id="username" placeholder="分类名称"  v-model="addData.name" style="width: 100%"/>
                    </Col>
                    </Row>
                </div>
                
                <br>

                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    上级分类：
                    </Col>
                    <Col span="18">
                    <Select  :filterable="true" :remote="true" @remote-method='getArticleSort' @on-query-change="setKeyword" :loading='false' style="width:100%" v-model="addData.father">
                        <Option :key="sort.id" v-for="sort in classData" :value="sort.id">{{sort.sort}}</Option>
                    </Select>
                    </Col>
                    </Row>
                </div>

                <br>

                <div class="Input_div">
                    <Row type="flex" align="middle">
                        <Col span="6">
                            <div style="width:100%;display:inline-block"></div>
                        </Col>
                        <Col span="18">
                            <Button type="primary" long @click="addAticleClass">添加</Button>
                        </Col>
                    </Row>
                    
                </div>
            </div>
            </Col>
        </Row>
    </div>
</template>
<style scoped>
    #title{
        font-size: 20px;
        margin-top:60px;
    }
    #container{
    }

    #Input{
        margin-top:20px;
    }
    .Input_div{
        width: 300px;
    }
</style>
<script>
    export default {
        name:'Articlesortadd',
        data () {
            return {
                classData:[],
                addData:{
                    name:'',
                    father:0,
                },
                add_url:'/mapi/index/addArticleClass?add=1',
                search_url: '/mapi/index/addArticleClass?add=1',
                keyword:{
                    s:''
                },
            }
        },
        methods:{
            addAticleClass:function(){
                var app = this;
                if(this.addData.name==''){
                    this.$Message.warning('请输入分类名称');
                    return;
                }
                //console.log(this.addData);return;
                //console.log(this.addData);
                this.$post(this.add_url,this.addData)
                .then(data=>{
                    if(data.status=='error'){
                        switch(data.type){
                            case 'error_params':
                                app.$Message.warning('请求参数有误！');
                                break;
                            case 'empty_data':
                                app.$Message.warning('分类名称不能为空！');
                                break;
                            case 'exit_data':
                                app.$Message.warning('分类名称已存在！');
                                break;
                            case 'not_add':
                                app.$Message.warning('添加失败！');
                                break;
                            default:
                                break;
                        }
                    }else if(data.status=='success'){
                        console.log(data);
                        app.$Message.success('添加成功，正在跳转！');
                        setTimeout(function(){
                            //window.location.href = '/article/article_sort';
                        },1500);
                    }
                });

            },
            getArticleSort(){
                // this.$post('/mapi/index/getArticlesort?a=1',this.keyword)
                // .then(data=>{
                //     console.log(data);
                //     this.classData = data;
                // });
            },
            setKeyword(e){
                this.keyword.s = e;
                this.$post('/mapi/index/getArticlesort?a=1',this.keyword)
                .then(data=>{
                    console.log(data);
                    this.classData = data;
                })
                .catch(data=>{
                    console.log(data);
                });
            }
        },
        props:[],
        created:function(){
            this.$fetch('/mapi/index/getArticlesort?a=1')
            .then(data=>{
                console.log(data);
                this.classData = data;
            });
        }
    }
</script>
