<template>
    <div>
        <script :id="editor_id" type="text/plain"></script>
    </div>
</template>
<script>
    
    import '../../static/ueditor/ueditor.config';
    import '../../static/ueditor/ueditor.all';
    import '../../static/ueditor/lang/zh-cn/zh-cn';

    export default {
        name:'Ueditor',
        //编辑器接收外部自定义设置
        props:{
            ueditorConfig:{
                type:Object,
                required: true
            },
            uploadUrl:{
                type:Object,
                required: true
            },
            setOpt:{
                type:Object,
                required: true
            }
        },
        data () {
            return {
                editor_id:'ueditor_' + (Math.random() * 100000000000000000),
                instance:null,//编辑器实例
                config:{
                    zIndex:0,
                    enableAutoSave :false,
                    imageScaleEnabled:false,
                    imagePopup:false,
                    pasteplain:true,
                    enableContextMenu:false,
                    imageScaleEnabled :false,
                    autotypeset :{
                        imageBlockLine: 'center',
                        removeEmptyNode: true
                    },
                    retainOnlyLabelPasted :true,
                    toolbars: [
                    ['source','undo', 'redo', 'bold','insertimage','indent','insertorderedlist','insertunorderedlist','justifycenter']],

                },
                upload:{
                    //图片上传地址，需要百度编辑器后端配置
                    uploadImageUrl:'http://www.test.com/mapi/uploadimage/uploadimage?action=uploadimage',
                    uploadVideoUrl:''
                },

                //百度编辑器上传相关参数，一般在后端传回给前端，现在直接写在前端，详情看百度编辑器官方文档
                option: {
                    imageActionName : 'uploadimage',
                    imageFieldName  : 'upfile',
                    imageMaxSize    : 2048000*5,
                    imageAllowFiles : ['.png','.jpg','.jpeg','.bmp'],
                    imagePathFormat : "/static/upload/image/{yyyy}{mm}{dd}{time}{rand:6}",
                    imageUrl        : 'http://www.test.com/mapi/uploadimage/uploadimage?action=uploadimage',
                    imageUrlPrefix  :  'http://www.test.com',
                },
                
            }
        },
        methods:{

            //初始化编辑器
            initEditor () {
              this.$nextTick(() => {
                var app = this;
                UE.Editor.prototype._bkGetActionUrl = UE.Editor.prototype.getActionUrl;
                UE.Editor.prototype.getActionUrl = function(action) {
                    if (action == 'uploadimage' || action == 'uploadscrawl' || action == 'uploadimage') {
                        return app.uploadUrl.uploadImageUrl?app.uploadUrl.uploadImageUrl:app.upload.uploadImageUrl;
                    } else if (action == 'uploadvideo') {
                        return app.uploadUrl.uploadVideoUrl?app.uploadUrl.uploadVideoUrl:app.upload.uploadVideoUrl;
                    }
                }

                if(this.isEmpty(this.ueditorConfig))
                    if(this.isEmpty(this.config))
                    this.instance = UE.getEditor(this.editor_id);
                    else
                    this.instance = UE.getEditor(this.editor_id,this.config);
                else{
                    this.instance = UE.getEditor(this.editor_id,this.ueditorConfig);
                }
                
                //非后端环境下无法加载config.json,前端自己手动设置
                this.instance.setOpt('imageActionName',(this.setOpt&&this.setOpt.imageActionName)?this.setOpt.imageActionName:this.option.imageActionName);

                this.instance.setOpt('imageFieldName',(this.setOpt&&this.setOpt.imageFieldName)?this.setOpt.imageFieldName:this.option.imageFieldName);

                this.instance.setOpt('imageMaxSize',(this.setOpt&&this.setOpt.imageMaxSize)?this.setOpt.imageMaxSize:this.option.imageMaxSize);

                this.instance.setOpt('imageAllowFiles',(this.setOpt&&this.setOpt.imageAllowFiles)?this.setOpt.imageAllowFiles:this.option.imageAllowFiles);
                this.instance.setOpt('imagePathFormat',(this.setOpt&&this.setOpt.imagePathFormat)?this.setOpt.imagePathFormat:this.option.imagePathFormat);
                this.instance.setOpt('imageUrl',(this.setOpt&&this.setOpt.imageUrl)?this.setOpt.imageUrl:this.option.imageUrl);

                this.instance.setOpt('imageUrlPrefix',(this.setOpt&&this.setOpt.imageUrlPrefix)?this.setOpt.imageUrlPrefix:this.option.imageUrlPrefix);

                //console.log(this.instance.isServerConfigLoaded());
                this.instance.addListener('ready', () => {
                    this.$emit('ready', this.instance);
                });

              });
            },
            isEmpty(obj){
                for(var i in obj){
                    return false;
                }
                return true;
            }
        },
        mounted(){
            this.initEditor();
        }
    }
</script>
<style type="text/css" scoped>
    
    
</style>