
<template>
    <div id="MyHeader">
    <Row>
    <Col class="Col" id="Col_title" span="4">创营网</Col>
    <Col class="Col" id="Col_header" push="17" span="2"> 
        <div id="Col_header_setborder" @mouseover="addBorder()" @mouseout="removeBorder()">
        <Dropdown @on-click="logout" id="Dropdown" ref="Dropdown" placement="bottom" @on-visible-change="menusChange()" :style="dropdownStyle" >
        <div class="demo-avatar">
            <Avatar v-if="showHeader" :src="src" />
            <Avatar v-else style="background-color: #87d068" icon="ios-person" />
            <svg class="icon" aria-hidden="true">
                <use v-if="selectIcon" xlink:href="#icon-shangla"></use>
                <use v-else xlink:href="#icon-xiala"></use>
            </svg>
        </div>
        <DropdownMenu slot="list">
            <DropdownItem>退出</DropdownItem>
        </DropdownMenu>
        </Dropdown>
        </div>
    </Col>
    
    </Row>

    <Modal v-model="is_logout" width="288">
        <p slot="header" style="height:18px;color:#f60">
            <Icon type="ios-information-circle"></Icon>
            <span>提示</span>
        </p>
        <div style="text-align:center;font-size:18px;">
            <p>您确定要退出吗？</p>
        </div>
        <div slot="footer" id="logout">
            <Button type="default" @click="quitLogout">取消</Button>
            <Button type="primary" @click="logoutSuccess">确定</Button>
        </div>
    </Modal>
    </div>
    
</template>
<style scoped>
    #MyHeader{
        background: #fff;
        height: 100%;
        width: 100%;
    }
    #Icon{
        margin-left: 10px;
    }
    .icon{
        margin-left: 10px;
    }
    #business_img{
        width: 100%;
        height: 100%;

    }
    .Col{
       
    }
    #Col_title{
        color:#FFC125; 
        text-align: center;
        font-size: 25px;
    }
    #Col_header{
        text-align: center;
    }
    
    #Dropdown{
        width: 100%;
    }
    #Col_header_setborder{

    }

</style>
<script>
    export default {
        name: 'MyHeader',
        data () {
            return {
              src:"http://t2.hddhhn.com/uploads/tu/201708/864/b35a7a67072.jpg",
              visible:false,
              selectIcon:false,
              dropdownStyle:'',
              logoutUrl:'mapi/login/logout?out=1',
              is_logout:false,
            }
        },
        computed: {
            showHeader:function(){
                if(this.src)
                    return true;
                else
                    return false;
            },
           
        },
        methods:{
            menusChange:function(){
                if(this.visible===true){
                    this.selectIcon = true;
                    this.dropdownStyle  = 'border-bottom:1px solid #00bfff';
                }
                else{
                    this.selectIcon = false;
                    this.dropdownStyle = '';
                }
            },
            addBorder:function(){
                this.visible = true;
            },
            removeBorder:function(){
                this.visible = false;
            },
            logoutSuccess:function(){
                window.localStorage.setItem('jwt','');
                this.is_logout = false;
                this.$Message.success('已成功退出当前账号!');
                setTimeout(function(){
                    window.location.href = '/';
                },1500);
            },
            logout:function(){
                this.is_logout = true;
            },
            quitLogout:function(){
                this.is_logout = false;
            }
        },
    }
</script>
