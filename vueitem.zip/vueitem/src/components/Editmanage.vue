<template>
    <div id="container">
        <Row type="flex" justify="center">
            <Col span="10">
                <div id="title">
                    管理员编辑
                </div>
            </Col>
        </Row>
        <br>
        <Row type="flex" justify="center">
            <Col span="10">
            <div id="Input">
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    <span class="must">*</span>
                    账号：
                    </Col>
                    <Col span="18">
                    <Input type='text' id="username" prefix="ios-contact" placeholder="管理员账号"  v-model="userData.name" style="width: 100%"/>
                    </Col>
                    </Row>
                </div>
                
                <br>
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    密码：
                    </Col>
                    <Col span="18">
                    <Input type='password' id="password" prefix="ios-lock" placeholder="管理员密码" v-model="userData.password" style="width: 100%" />
                    </Col>
                    </Row>
                </div>
                
                <br>

                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    私匙：
                    </Col>
                    <Col span="18">
                    <Input type='text' id="private_key" prefix="ios-lock" placeholder="自定义密匙" v-model="userData.private_key" style="width: 100%" />
                    </Col>
                    </Row>
                </div>
                
                <br>
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    权限：
                    </Col>
                    <Col span="18">
                    <Select style="width:100%" v-model="userData.auth" :label="userData.auth">
                        <Option :key="auth.auth" :label="auth.auth" v-for="auth in auths" :value="auth.auth" >{{auth.auth}}</Option>
                    </Select>
                    </Col>
                    </Row>
                </div>

                <br>

                <div class="Input_div">
                    <Row type="flex" align="middle">
                        <Col span="6">
                            <div style="width:100%;display:inline-block"></div>
                        </Col>
                        <Col span="18">
                            <Button type="primary" long @click="editmanager">保存</Button>
                        </Col>
                    </Row>
                    
                </div>
            </div>
            </Col>
        </Row>
    </div>
</template>
<style scoped>
    #title{
        font-size: 20px;
        margin-top:30px;
    }
    #container{
    }

    #Input{
        margin-top:20px;
    }
    .Input_div{
        width: 300px;
    }
</style>
<script>
    export default {
        name:'Addmanage',
        data () {
            return {
                auths:{},
                userData:{
                    id:0,
                    name:'',
                    password:'',
                    private_key:'',
                    auth:3
                },
                edit_url:'/mapi/index/editmanager',
            }
        },
        methods:{
            editmanager:function(){
                var app = this;
                if(this.userData.name==''){
                    this.$Message.warning('请输入管理员账号');
                    return;
                }
                console.log(this.userData);
                this.$post(this.edit_url,this.userData)
                .then(data=>{
                    if(data.status=='error'){
                        switch(data.type){
                            case 'no_user':
                            app.$Message.warning('用户不存在!');
                            break;
                            case 'no_auth':
                            app.$Message.warning('权限不足!');
                            break;
                            case 'error_params':
                            app.$Message.warning('非法操作!');
                            break;
                            case 'no_input_name':
                            app.$Message.warning('请输入管理员账号!');
                            break;
                            case 'not_update':
                            app.$Message.warning('修改失败!');
                            break;
                            default:
                            break;
                        }
                    }else if(data.status=='success'){
                        if(data.type == 're_login'){
                            window.localStorage.setItem('jwt','');
                            app.$Message.warning('密码已修改，请重新登录!');
                            setTimeout(function(){
                                window.location.href = '/';
                            },1000);
                            return;
                        }
                        console.log(data);return;
                        app.$Message.success('修改成功，正在跳转！');
                        setTimeout(function(){
                            window.localStorage.setItem('manageredit','');
                            window.location.href = '/manager/manager_list';
                        },1500);
                    }
                });

            }
        },
        props:[],
        created:function(){
            this.$fetch('/mapi/index/selectAuth?a=1')
            .then(data=>{
                console.log(data);
                this.auths = data;
                this.userData = JSON.parse(window.localStorage.getItem('manageredit'));
            });
            
            //window.localStorage.setItem('manageredit','');
        }
    }
</script>
