<template>
    <div id="login">
        <Row type="flex" justify="center">
            <Col span="6">
                <div id="title">
                    管理员登录
                </div>
            </Col>
        </Row>
        <br>
        <Row type="flex" justify="center">
            <Col span="6">
            <div id="Input">
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="4">
                    账号：
                    </Col>
                    <Col span="20">
                    <Input type='text' id="username" prefix="ios-contact" placeholder="管理员账号" style="width: 100%" v-model="userData.username"/>
                    </Col>
                    </Row>
                </div>
                
                <br>
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="4">
                    密码：
                    </Col>
                    <Col span="20">
                    <Input type='password' id="password" prefix="ios-lock" placeholder="管理员密码" style="width: 100%" v-model="userData.password"/>
                    </Col>
                    </Row>
                </div>

                <br>

                <div class="Input_div">
                    <Row type="flex" align="middle">
                        <Col span="4">
                            <div style="width:100%;display:inline-block"></div>
                        </Col>
                        <Col span="20">
                            <Button type="primary" long @click="login">登陆</Button>
                        </Col>
                    </Row>
                </div>
            </div>
            </Col>
        </Row>

    </div>
</template>
<style scoped>
    #login{
        margin-top:188px;
        display: inline-block;
        width: 100%;
        height: 100%;
    }
    #title{
        font-size: 20px;
        text-align: center;
    }
    .Input_div{
        font-size: 16px;
    }
</style>
<script>
    export default {
        name: 'Login',
        data () {
            return {
                userData:{
                    username:'',
                    password:''
                },
                loginUrl:'mapi/login/login',
            }
        },
        computed: {

        },
        methods:{
            login:function(){
                
                var app = this;
                var userData = this.userData;
                var loginUrl = this.loginUrl;
                this.$post(loginUrl,userData)
                .then(data=>{
                    if(data.login){
                        setTimeout(function(){
                            app.$emit('loginStatus',data);
                            //iview
                            app.$Message.success('登录成功!');
                        },200);
                    }else{
                        if(data.not_user)
                        this.$Message.warning('用户不存在或密码错误!');
                        if(data.not_token)
                        this.$Message.warning('token生成失败!');
                    }
                }).catch(error=>{
                    reject(error);
                });
            }
        },
    }
</script>
