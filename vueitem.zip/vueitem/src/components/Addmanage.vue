<template>
    <div id="container">
        <Row type="flex" justify="center">
            <Col span="10">
                <div id="title">
                    添加管理员
                </div>
            </Col>
        </Row>
        <br>
        <Row type="flex" justify="center">
            <Col span="10">
            <div id="Input">
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    <span class="must">*</span>
                    账号：
                    </Col>
                    <Col span="18">
                    <Input type='text' id="username" prefix="ios-contact" placeholder="管理员账号"  v-model="userData.username" style="width: 100%"/>
                    </Col>
                    </Row>
                </div>
                
                <br>
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    <span class="must">*</span>
                    密码：
                    </Col>
                    <Col span="18">
                    <Input type='password' id="password" prefix="ios-lock" placeholder="管理员密码" v-model="userData.password" style="width: 100%" />
                    </Col>
                    </Row>
                </div>
                
                <br>

                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    私匙：
                    </Col>
                    <Col span="18">
                    <Input type='text' id="private_key" prefix="ios-lock" placeholder="自定义密匙" v-model="userData.private_key" style="width: 100%" />
                    </Col>
                    </Row>
                </div>
                
                <br>
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    权限：
                    </Col>
                    <Col span="18">
                    <Select style="width:100%" v-model="userData.auth">
                        <Option :key="auth.auth" v-for="auth in auths" value="auth.auth">{{auth.auth}}</Option>
                    </Select>
                    </Col>
                    </Row>
                </div>

                <br>

                <div class="Input_div">
                    <Row type="flex" align="middle">
                        <Col span="6">
                            <div style="width:100%;display:inline-block"></div>
                        </Col>
                        <Col span="18">
                            <Button type="primary" long @click="addmanager">添加</Button>
                        </Col>
                    </Row>
                    
                </div>
            </div>
            </Col>
        </Row>
    </div>
</template>
<style scoped>
    #title{
        font-size: 20px;
        margin-top:30px;
    }
    #container{
    }

    #Input{
        margin-top:20px;
    }
    .Input_div{
        width: 300px;
    }
</style>
<script>
    export default {
        name:'Addmanage',
        data () {
            return {
                auths:{},
                userData:{
                    username:'',
                    password:'',
                    private_key:'',
                    auth:3
                },
                add_url:'/mapi/index/addmanager',
            }
        },
        methods:{
            addmanager:function(){
                var app = this;
                if(this.userData.username==''){
                    this.$Message.warning('请输入管理员账号');
                    return;
                }

                if(this.userData.password==''){
                    this.$Message.warning('请输入管理员密码');
                    return;
                }

                if(this.userData.password.length<6){
                    this.$Message.warning('管理员密码不能少于6位');
                    return;
                }

                this.$post(this.add_url,this.userData)
                .then(data=>{
                    if(data.status=='error'){
                        switch(data.type){
                            case 'exit_user':
                                app.$Message.warning('账号已存在！');
                                break;
                            case 'not_add':
                                app.$Message.warning('添加失败！');
                                break;
                            default:
                                break;
                        }
                    }else if(data.status=='success'){
                        app.$Message.success('添加成功，正在跳转！');
                        setTimeout(function(){
                            window.location.href = '/manager/manager_list';
                        },1500);
                    }
                });

            }
        },
        props:[],
        created:function(){
            this.$fetch('/mapi/index/selectAuth?a=1')
            .then(data=>{
                console.log(data);
                this.auths = data;
            });
        }
    }
</script>
