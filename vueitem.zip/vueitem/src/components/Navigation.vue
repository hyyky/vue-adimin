<template>
<div>
    <ul id='navigation' @mouseleave="leaveMenus" :style="{background:setStyle.menusBackground}">
        <li v-for="item in menusData" :child="item.havechild" @mouseenter="showMenus(item.child,$event)" @mouseleave="hideMenus($event,setStyle.menusBackground)" :key="item.name" :ref="item.name">

            <div v-if="item.havechild" class="div">
                <svg class="icon" aria-hidden="true">
                    <use v-bind:xlink:href="item.icon"></use>
                </svg>
                {{item.title}}
                <span class="span">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-arrow"></use>
                    </svg>
                </span>
            </div>

            <div v-else class="div" @click="href(item.href)">
                <svg class="icon" aria-hidden="true">
                    <use v-bind:xlink:href="item.icon"></use>
                </svg>
                {{item.title}}
                <span class="span">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-arrow"></use>
                    </svg>
                </span>
            </div>

        </li>
    </ul>
</div>
</template>
<style scoped>
    ul{
        text-align: center;
        background: #fff;
    }
    li{
        list-style-type:none;
        width: 100%;
        height: 60px;
        line-height: 60px;
        cursor: default;
        font-size: 16px;
        position: relative;
    }
    .div{
        text-align: left;
        display: inline-block;
        width: 120px;
        max-width: 70%;
    }
    .span{
        float: right;
    }

</style>

<script>
export default {
     name: 'Navigation',
     data () {
        return {
            menus:{
                article:{
                    child:{
                        list: {name: "article_list", title: "文章列表", icon: "", havechild: false,href: "/article/article_list",child:{}},
                        sort: {name: "article_sort", title: "文章分类", icon: "", havechild: false,href: "/article/article_sort",child:{}},
                        add: {name: "article_add", title: "添加文章", icon: "", havechild: false,href: "/article/article_add",child:{}}
                    },
                    havechild: true,
                    href:'',
                    icon:"#icon-wenzhang1",
                    name: "article",
                    title: "文章管理"
                },

                manager: {
                    child: {
                        list: {name: "manager_list",title: "管理员列表",icon: "",havechild: false,href: "/manager/manager_list",child:{}}
                    },
                    havechild: true,
                    href: "",
                    icon: "#icon-guanliyuanbidu",
                    name: "manager",
                    title: "用户管理"
                },

                advert:{
                    child:{
                        list: {name: "advert_list", title: "广告列表", icon: "", havechild: false, href: "/advert/advert_list",child:{}},
                        sort: {name: "advert_sort", title: "广告分类", icon: "", havechild: false, href: "/advert/advert_sort",child:{}}
                    },
                    havechild: true,
                    href:'',
                    icon:"#icon-wenzhang1",
                    name: "advert",
                    title: "广告管理"
                },
                
            },
            setStyle:{
                color:'#000000',
                activeColor:'#c61ce3',
                background:'#fff',
                menusBackground:'#fff',
                activeBackground:'#fff',
                childBackground:'#fff',
                childActiveBackground:'#fff',
                childColor:'#000000',
                childActiveColor:'#c61ce3',
                divWidth:120,
                divMaxWidth:70,
                reqestUrl:'/manage/index/getMenus?m=1',
            },
            //activeMenus:window.location.pathname.slice(window.location.pathname.indexOf('/')+1,window.location.pathname.lastIndexOf('/')),
            activeMenus:window.location.pathname.split('/')[1],
        }
    },
    props:{
        menusStyle:Object,
        setMenus:Object,
    },
    methods:{
        showMenus:function(child,e){
            if(e&&e.target){
                //列表元素
                var tar = e.target;
                var activeColor = this.setStyle.activeColor;
                var activeBackground = this.setStyle.activeBackground;
                var style = {
                    color:this.setStyle.color,
                    background:this.setStyle.background,
                    activeColor:this.setStyle.activeColor,
                    activeBackground:this.setStyle.activeBackground
                };
                
            }else{
                //动态创建的子元素
                var tar = e;
                var activeColor = this.setStyle.childActiveColor;
                var activeBackground = this.setStyle.childActiveBackground;
                
                var style = {
                    color:this.setStyle.childColor,
                    background:this.setStyle.childBackground,
                    activeColor:this.setStyle.childActiveColor,
                    activeBackground:this.setStyle.childActiveBackground
                };
            }
            
            this.setElement(tar,this.activeMenus,style,true);

            tar.style.color = activeColor;
            tar.style.background = activeBackground;
            var havechild = eval(tar.getAttribute('child'));

            if(havechild){
                var childNode = tar.children.children;
                for(var i in childNode){
                    if(childNode[i].tagName && childNode[i].tagName.toLocaleLowerCase()=='ul'){
                        return;
                    }
                }
                var width = tar.parentNode.offsetWidth;
                var ul = document.createElement("ul");
                ul.style.width = width+'px';
                ul.style.textAlign = 'center';
                ul.style.background = this.setStyle.childBackground;
                ul.style.position = 'absolute';
                ul.style.left = width+'px';
                ul.style.border = '1px solid #EAEAEA';
                ul.style.top = 0+'px';
                ul.style.zIndex = 2;
                for(var i in child){
                    var li = document.createElement("li");
                    var div = document.createElement("div");
                    li.setAttribute('child',child[i].havechild);
                    li.setAttribute('key',child[i].name);
                    li.setAttribute('ref',child[i].name);
                    li.style.listStyle = 'none';
                    li.style.position = 'relative';
                    li.style.textAlign = 'center';
                    li.style.color = this.setStyle.color;
                    div.style.width = this.setStyle.divWidth+'px';
                    div.style.textAlign = 'left';
                    div.style.maxWidth = this.setStyle.divMaxWidth+'%';
                    var maxWidth = width*this.setStyle.divMaxWidth/100;
                    div.style.marginLeft = (width-(this.setStyle.divWidth<maxWidth?this.setStyle.divWidth:maxWidth))/2+'px';
                    var span = document.createElement("span");
                    span.style.float = 'right';
                    span.innerHTML = '<svg class="icon" aria-hidden="true"><use xlink:href="#icon-arrow"></use></svg>';

                    div.innerHTML = child[i].title;

                    //闭包
                    (function(child,li,childBackground,app,element){
                        li.addEventListener('mouseenter',function(){
                            app.showMenus(child.child,li);
                        });
                        li.addEventListener('mouseleave',function(){
                            app.hideMenus(li,childBackground);
                        });
                        //绑定路由
                        if(!child.havechild){
                            element.addEventListener('click',function(){
                                app.href(child.href);
                            });
                        }
                    }(child[i],li,this.setStyle.childBackground,this,div));

                    ul.appendChild(li);
                    li.appendChild(div);
                    div.appendChild(span);
                }
                tar.appendChild(ul);
            }
            event.stopPropagation();
            return false;
        },
        hideMenus:function(e,background){

            if(e&&e.target){
                //列表元素
                var tar = e.target;
                var color = this.setStyle.color;
            }else{
                //动态创建的子元素
                var tar = e;
                var color = this.setStyle.childColor;
            }

            tar.style.color = color;
            tar.style.background = background;
            if(tar.tagName && tar.tagName.toLocaleLowerCase()=='li'){
                tar = tar.lastChild;
                if(tar.tagName && tar.tagName.toLocaleLowerCase()=='ul'){
                    this.remove(tar);
                }
            }
        },
        hideMe:function(e){
            this.remove(e);
        },
        leaveMenus:function(e){
            var tar  = e.target;
            this.setElement(tar,this.activeMenus);
        },
        href:function(url){
            window.location.href = url;
            //window.location.href = 'http://'+window.location.host+'/#'+url;
            //alert(window.location.href);
        },
        emptyObject:function(obj={}){
            for(var i in obj){
                return false;
            }
            return true;
        },
        setElement:function(tar,activeMenus,style={},boo=false){
            
            //鼠标进来hover
            if(boo){
                //兼容大小写
                var bks = this.changeColor(tar.style.background).toLowerCase();
                var bkb = this.changeColor(tar.style.background).toUpperCase();
                var cls = this.changeColor(tar.style.color).toLowerCase();
                var clb = this.changeColor(tar.style.color).toUpperCase();

                var childNode = tar.parentNode.children;
                for(var j in childNode){
                    if(childNode[j].style){
                        if(bks!==style.activeBackground && bkb!==style.activeBackground){
                            //兼容大小写
                            var backs = this.changeColor(childNode[j].style.background).toLowerCase();
                            var backb = this.changeColor(childNode[j].style.background).toUpperCase();
                            if(backs==style.activeBackground || backb==style.activeBackground){
                                childNode[j].style.background = style.background;
                                break;
                            }
                        }

                        if(cls!==style.activeColor && clb!==style.activeColor){
                            //兼容大小写
                            var colors = this.changeColor(childNode[j].style.color).toLowerCase();
                            var colorb = this.changeColor(childNode[j].style.color).toUpperCase();
                            if(colors==style.activeColor || colorb==style.activeColor){
                                childNode[j].style.color = style.color;
                                break;
                            }
                        }else{
                            break;
                        }
                    }
                }
                tar.style.color = style.activeColor;
                tar.style.background = style.activeBackground;
               
            }
            //鼠标离开
            else{
                
                if(activeMenus){
                    this.$nextTick(function(){
                        var refs = this.$refs;
                        if(this.$refs[activeMenus]&&this.$refs[activeMenus][0]){
                            this.$refs[activeMenus][0].style.color = this.setStyle.activeColor;
                            this.$refs[activeMenus][0].style.background = this.setStyle.activeBackground;
                        }
                            
                    });
                }
            }
            
        },
        //定位(标识菜单)
        setLocationStyle:function(activeMenus){
            this.$nextTick(function(){

                var refs = this.$refs;

                if(!activeMenus || !this.$refs[activeMenus])
                    return;
                
                this.$refs[activeMenus][0].style.color = this.setStyle.activeColor;
                this.$refs[activeMenus][0].style.background = this.setStyle.activeBackground;
            });
        },
        //js RGB=>16进制
        changeColor:function(value) {
            if (/rgba?/.test(value)) {
                var array = value.split(",");
                if (array.length > 3)
                    return "";
                value = "#";
                for (var i = 0, color; color = array[i++];) {
                    color = parseInt(color.replace(/[^\d]/gi, ''), 10).toString(16);
                    value += color.length == 1 ? "0" + color : color;
                }
                value = value.toUpperCase();
            }
            return  value;
        },
        //设置菜单样式和获取菜单
        getMenus:function(){

            
            if(!this.emptyObject(this.menusStyle)){
                if(this.menusStyle.color){
                    this.setStyle.color = this.menusStyle.color;
                }
                if(this.menusStyle.activeColor){
                    this.setStyle.activeColor = this.menusStyle.activeColor;
                }
                if(this.menusStyle.background){
                    this.setStyle.background = this.menusStyle.background;
                }

                if(this.menusStyle.menusBackground){
                    this.setStyle.menusBackground = this.menusStyle.menusBackground;
                }
                if(this.menusStyle.activeBackground){
                    this.setStyle.activeBackground = this.menusStyle.activeBackground;
                }
                
                if(this.menusStyle.childBackground){
                    this.setStyle.childBackground = this.menusStyle.childBackground;
                }
                if(this.menusStyle.childActiveBackground){
                    this.setStyle.childActiveBackground = this.menusStyle.childActiveBackground;
                }
                if(this.menusStyle.childColor){
                    this.setStyle.childColor = this.menusStyle.childColor;
                }

                if(this.menusStyle.childActiveColor){
                    this.setStyle.childActiveColor = this.menusStyle.childActiveColor;
                }

                if(this.menusStyle.divWidth){
                    this.setStyle.divWidth = this.menusStyle.divWidth;
                }
                if(this.menusStyle.divMaxWidth){
                    this.setStyle.divMaxWidth = this.menusStyle.divMaxWidth;
                }
                if(this.menusStyle.reqestUrl){
                    this.setStyle.reqestUrl = this.menusStyle.reqestUrl;
                }

            }

            if(!this.emptyObject(this.menus)){
                this.setStyle.activeMenus = window.location.pathname.split('/')[1];
                this.setLocationStyle(this.setStyle.activeMenus);
                return;
            }

            if(this.emptyObject(this.setMenus)){
                this.$fetch(this.setStyle.reqestUrl)
                .then(data=>{
                    this.menus = data;
                    this.setStyle.activeMenus = window.location.pathname.split('/')[1];
                    this.setLocationStyle(this.setStyle.activeMenus);
                });
                
            }else{
                this.menus = this.setMenus;
                this.setStyle.activeMenus = window.location.pathname.split('/')[1];
                this.setLocationStyle(this.setStyle.activeMenus);
            }

        },
        isIE:function(){
            var ug = navigator.userAgent;
            console.log(ug);
            //IE和火狐
            if(ug.indexOf('Trident')>-1 ||ug.indexOf("Firefox")>-1)
                return true;

            return false;
        },
        remove:function(obj){
            if(this.isIE())
                obj.parentNode.removeChild(obj);
            else
                obj.remove(); 
        }
      
    },
    computed:{
        menusData:function(){
            this.getMenus();
            return this.menus;
        }
    },
    created:function(){
        console.log(window.location.host);
    },
    mounted:function(){
        this.getMenus();
    }
        
}
</script>