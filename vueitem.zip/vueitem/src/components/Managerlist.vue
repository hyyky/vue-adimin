<template>
    <div id="Managerlist">
        <Row>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
            <Col span='20'>
                <span id="title">管理员列表</span>
            </Col>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
        </Row>
        <br>
        <br>
        <Row :gutter='10'>
            
            <Col span="18">
                <div style="width:100%;display:inline-block"></div>
            </Col>
            <Col span='2' >
                <Button type="primary" long size='default' @click="addmanager">
                <span style="vertical-align: text-bottom;">
                    <Icon type="md-add" size="15"/>
                </span>
                <span style="font-size:15px;margin-left:2px;">添加</span>
                </Button>
            </Col>
            <Col span='2'>
                <Button type="error" long size='default' @click="batchDelete">
                <span style="vertical-align: text-bottom;">
                    <Icon type="ios-trash" size="15"/>
                </span>
                <span style="font-size:15px;margin-left:2px;">删除</span>
                </Button>
            </Col>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
        </Row>
        <br>
        <Row>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
            <Col span='20'>
                <Table v-if="dataEmpty" width="888" border ref="selection" :columns="columns" :data="data"></Table>
                <Table v-else @on-select="getSelect" @on-select-all="getSelect" border ref="selection" @on-select-cancel="getSelect" @on-selection-change="getCacelSelect" :columns="columns" :data="data"></Table>
            </Col>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
        </Row>
        <Modal v-model="is_delete" width="288">
            <p slot="header" style="height:18px;color:#f60">
                <Icon type="ios-information-circle"></Icon>
                <span>提示</span>
            </p>
            <div style="text-align:center;font-size:18px;">
                <p>您确定要删除吗？</p>
            </div>
            <div slot="footer" id="logout">
                <Button type="default" @click="quitDelete">取消</Button>
                <Button type="primary" @click="deleteSuccess">确定</Button>
            </div>
        </Modal>
    </div>
</template>
<style scoped>
    #Managerlist{
        margin-top:66px;
    }
    #title{
        font-size: 18px;
    }
    td{
        width: auto;
    }
</style>
<script>
    export default {
        name: 'Managerlist',
        data () {
            return {
                columns: [
                    {
                        type: 'selection',
                        width: 50,
                        align: 'center'
                    },
                    {
                        title: '账号',
                        key: 'name',
                        align: 'center'
                    },
                    {
                        title: '权限等级',
                        key: 'auth',
                        align: 'center'
                    },
                    {
                        title: '添加时间',
                        key: 'add_time',
                        align: 'center'
                    },
                    {
                        title: '修改时间',
                        key: 'update_time',
                        align: 'center'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 150,
                        align: 'center',
                        render:(h,args)=>{
                            return h('div',[
                                h('Button',{
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            console.log(args.row.id);
                                            this.edit(args.row.id)
                                        }
                                    }
                                },'编辑'),
                                h('Button',{
                                    props: {
                                        type: 'error',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.remove(args.row.id,args.index)
                                        }
                                    }
                                },'删除'),
                            ])
                        }
                    }
                ],
                data: [
                    
                ],
                is_delete:false,
                delete_index:'',
                delete_id:{id:''},
                getManagersUrl:'mapi/index/getManagers?gm=1',//管理员列表
                getManagerUrl:'mapi/index/getManager?ed=1',//一条管理员信息
                delManagerUrl:'mapi/index/delManager?del=1',

            }
        },
        computed:{
            dataEmpty:function(){
                if(this.isEmpty(this.data)){
                    return true;
                }
                return false;
            }
        },
        methods:{
            isEmpty:function(obj){
                for(var i in obj){
                    return false;
                }
                return true;
            },
            show (index) {
                this.$Modal.info({
                    title: 'User Info',
                    content: `Name：${this.data[index].name}<br>Auth：${this.data[index].auth}<br>Add_time：${this.data[index].add_time}<br>Update_time：${this.data[index].update_time}`
                })
            },
            edit(id){
                var app = this;
                this.$post(this.getManagerUrl,{
                    id:id,
                }).then(data=>{
                    console.log(data);
                    if(data.status=='error'){
                        switch(data.type){
                            case 'no_user':
                            app.$Message.warning('用户不存在!');
                            break;
                            case 'no_auth':
                            app.$Message.warning('权限不足!');
                            break;
                            case 'error_params':
                            app.$Message.warning('非法操作!');
                            break;
                            default:
                            break;
                        }
                        return;
                    }else if(data.status=='success'){
                        window.localStorage.setItem('manageredit',JSON.stringify(data.data));
                        window.location.href  = '/manager/manager_edit';
                    }
                })
            },
            remove (id,index) {

                if(!id){
                    return;
                }

                this.delete_index = index;
                this.delete_id = {id:id};
                this.is_delete = true;
            },
            addmanager(){
                window.location.href = '/manager/manager_add';
            },
            deleteSuccess(){
                if(this.delete_id.id.length==0){
                    this.$Message.warning('请先选择要删除的项目!');
                }
                var app = this;
                this.is_delete = false;
                this.$post(this.delManagerUrl,this.delete_id)
                .then(data=>{
                    if(data.status == 'error'){
                        switch(data.type){
                            case 'no_user':
                            app.$Message.warning('用户不存在!');
                            break;
                            case 'no_auth':
                            app.$Message.warning('权限不足!');
                            break;
                            case 'not_delete':
                            app.$Message.warning('删除失败!');
                            break;
                            case 'error_params':
                            app.$Message.warning('非法操作!');
                            break;
                            case 'delete_self':
                            app.$Message.warning('不能删除自己!');
                            break;
                            default:
                            break;
                        }
                        console.log(data);
                        return;
                    }else if(data.status=='success'){
                        var ids = this.delete_id.id;
                        var listdata = this.data;
                        if(typeof ids === 'object' && ids.length>0){
                            for(var i in ids){
                                for(var j in listdata){
                                    if(ids[i] == listdata[j].id){
                                        listdata.splice(j,1);
                                    }
                                }
                            }
                        }else{
                            listdata.splice(this.delete_index,1);
                        }

                        setTimeout(function(){
                            app.$Message.success('删除成功!');
                        },300);
                    }
                });
            },
            
            quitDelete(){
                this.is_delete = false;
            },
            getSelect(selection){
                //console.log(selection);
                var ids = [];
                for(var i in selection){
                    if(selection[i] && selection[i].id)
                        ids.push(selection[i].id);
                }
                this.delete_id = {id:ids,json:true};
            },
            getCacelSelect(selection){
                console.log(selection);
                var ids = [];
                for(var i in selection){
                    if(selection[i] && selection[i].id)
                        ids.push(selection[i].id);
                }
                this.delete_id = {id:ids,json:true};
            },
            //批量删除
            batchDelete(){
                if(!this.delete_id.id ||this.delete_id.id==[] || this.delete_id.id.length==0){
                    this.$Message.warning('请先选择要删除的项目!');
                    return;
                }
                this.is_delete = true;
            }
        },
        created:function(){
            this.$fetch(this.getManagersUrl)
            .then(data=>{
                if(!data.status &&data.login==undefined){
                    console.log(data);
                    this.data = data;
                }
            });
        }
    }
</script>
