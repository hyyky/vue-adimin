<template>
    <div id="Addarticle">

        <div id="editor">
            <Row>
                <Col span='3'><div style="width:100%;display:inline-block;"></div></Col>
                <Col span='16'><div style="font-size:20px;letter-spacing:2px;">添加文章</div></Col>
            </Row>
            <br><br>
            <Row>
                <Col span='3'><div style="width:100%;display:inline-block;"></div></Col>
                <Col span='16'>
                <input id = 'article_title' type="text" maxlength="50" placeholder="标题不超过50个字" v-model="sumitContent.title">
                <Ueditor v-bind:upload-url="uploadUrl" v-bind:set-opt="setOpt" v-bind:ueditor-config="ueditorConfig" @ready="editorReady" ></Ueditor>
                </Col>
            </Row>
            <br><br><br>
            <Row type="flex" align="middle">
                <Col span='3'><div style="width:100%;display:inline-block;"></div></Col>
                <Col span='2'>分类：</Col>
                <Col span='6'>
                    <Select style="width:100%">
                        <!-- <Option :key="22"></Option> -->
                    </Select>
                </Col>
            </Row>
            <br><br><br>
            <Row type="flex" align="middle">
                <Col span='3'><div style="width:100%;display:inline-block;"></div></Col>
                <Col span='2'>封面：</Col>
                <Col span='15'>
                    <div id="img_poster">
                        <span @click="deletePoster" style='color:#fff;position:absolute;top:-10px;right:-10px;width:20px;height:20px;line-height:20px;border-radius:50%;text-align:center;background:#ddd;cursor: default;'>X</span>
                        <input type="hidden" id="poster" value="" />
                    </div>
                    <div id="add_poster" @click="shoowdiv">
                        <svg class="icon" aria-hidden="true">
                            <use xlink:href="#icon-add"></use>
                        </svg>
                    </div>
                </Col>
            </Row>
            <br><br><br>
            <Row type="flex" align="middle">
                <Col span='3'><div style="width:100%;display:inline-block;"></div></Col>
                <Col span='2'></Col>
                <Col span='6'>
                    <Button size="large" type="primary" @click="getContent">保存</Button>
                </Col>
            </Row>

        </div>
        
    </div>
</template>

<script>
    import Ueditor from './Ueditor';
    //import Cropper from 'cropperjs';
    export default {
        name:'Addarticle',
        data () {
            return {
                add_url:'/mapi/article/addarticle',
                // content:{
                //     content:'',
                //     title:'',
                // },
                uploadUrl:{
                    
                },
                sumitContent:{
                    title:'',
                    content:'',
                    imageUrl:{},
                    imageName:{},
                    otherImage:{},
                },
                setOpt:{
                    
                },
                ueditorConfig:{

                },
                instance:null,
                layerindex:null,
                content_body_html:'',
                cropper:null,
            }
        },
        methods:{
            editorReady (instance) {
                this.instance = instance;
                this.instance.setContent('');
                this.instance.addListener('contentChange', () => {
                  this.sumitContent.content = this.instance.getContent();
                });

                //console.log(instance.getOpt('imageActionName'));
            },
            deletePoster(e){
                $(e.target).parent().hide();
                $(e.target).siblings('#poster').val('');
            },
            closeImageIframe(){
                layer.closeAll();
            },
            createImageBox(imgiframe,imgArr){
                let html = '';
                for(var i in imgArr){
                    //判断封面类型，0代表上传的图片，1代表网络图片
                    if(imgArr[i].indexOf('/static/upload/image/')>-1){
                        var type = 0;
                    }else{
                        var type = 1;
                    }
                    
                    let imgbox = "<div data-type='"+type+"' data-img='"+imgArr[i]+"' class='imgbox' style='width:100px;height:100px;background:url("+imgArr[i]+") no-repeat 0px 0px;background-size:100px 100px;margin-left:20px;margin-top:20px;position:relative;display:inline-block;'></div>";

                    imgiframe.append(imgbox);

                }
                let app = this;
                //绑定点击事件
                $('.imgbox').click(function(e){
                    $(e.target).siblings().removeClass('active');
                    $(e.target).addClass('active');
                    var type = $(e.target).data('type');
                    $('#next').data('img',$(e.target).data('img'));
                    $('#next').data('type',type);
                    if(type==1){
                        $('#next').text('确定');
                        $('#next').click(function(ele){
                            var imgUrl = $(ele.target).data('img');
                            if(!imgUrl ||imgUrl==''){
                                app.$Message.warning('请选择图片！');
                                return;
                            }
                            $('#img_poster').css('background','url('+imgUrl+') no-repeat 0px 0px');
                            $('#img_poster').css('background-size','132px 88px');
                            $('#img_poster').css('display','inline-block');
                            $('#poster').val(imgUrl);
                            layer.close(app.layerindex);
                            app.layerindex = null;
                        });
                    }else if(type==0){
                        $('#next').text('下一步');
                        $('#next').click(function(ele){
                            var imgUrl = $(ele.target).data('img');
                            let imgHtml = "<div id='cut_body' style='width:100%;height:350px;text-align:center;'><img id='cut_img' src='"+imgUrl+"' /></div>"
                                +"<div id='content_foot' style='text-align:right;border-top:1px solid #ddd;'>"
                                +"<button class='layui-btn layui-btn-normal' id='prev' style='margin-top:8px;margin-right:10px;'>上一步</button>"
                                +"<button class='layui-btn layui-btn-normal' id='sure' style='margin-top:8px;margin-right:10px;'>确定</button>"
                                +"<button class='layui-btn layui-btn-primary' style='margin-top:8px;margin-right:10px;' onclick='layer.closeAll()'>取消</button>"
                                +"</div>";

                            layer.close(app.layerindex);
                            app.layerindex = layer.open({
                                  title:'剪裁图片',
                                  type: 1,
                                  skin: 'layui-layer-rim', //加上边框
                                  area: ['650px', '460px'], //宽高
                                  content: imgHtml,
                            });
                            let imgW = $('#cut_img').width();
                            let imgH = $('#cut_img').height();
                            console.log(imgW);
                            console.log(imgH);
                            if(imgH>650 || imgH>350){
                                if((imgW/650)>(imgH/350)){
                                    $('#cut_img').width('500px');
                                }else if((imgW/650)<(imgH/350)){
                                    $('#cut_img').height('300px');
                                }
                            }else{
                                $('#cut_img').width('500px');
                            }

                            $('#prev').click(function(ele){
                                app.shoowdiv();
                            });

                            var cut_img = document.getElementById('cut_img');

                            app.cropper = new Cropper(cut_img, {
                              aspectRatio: 16 / 9,
                              minCropBoxWidth:50,
                              autoCropArea:1,
                              viewMode:1,
                              zoomable:false,
                              scalable:false,
                              rotatable:false,
                              movable:false,
                              crop(event) {
                                console.log(event);
                                // console.log(event.detail.x);
                                // console.log(event.detail.y);
                                // console.log(event.detail.width);
                                // console.log(event.detail.height);
                                // console.log(event.detail.rotate);
                                // console.log(event.detail.scaleX);
                                // console.log(event.detail.scaleY);
                              },
                            });
                            console.log(app.cropper);

                            $('#sure').click(function(ele){
                                
                            });

                            
                        });
                    }
                });
            },
            emptyObject:function(obj={}){
                for(var i in obj){
                    return false;
                }
                return true;
            },
            shoowdiv(){
                this.getContent();

                if(this.emptyObject(this.sumitContent.imageUrl) && this.emptyObject(this.sumitContent.otherImage)){
                    this.$Message.warning('暂无可用图片，请先上传！');
                    return;
                }

                let app = this;
                let next = '下一步';
                let html = "<div id='content_body' style='width:100%;height:350px;overflow-y:auto'></div>"

                +"<div id='content_foot' style='text-align:right;border-top:1px solid #ddd;'>"
                +"<button class='layui-btn layui-btn-normal' id='next' style='margin-top:8px;margin-right:10px;'>"+next+"</button>"
                +"<button class='layui-btn layui-btn-primary' style='margin-top:8px;margin-right:10px;' onclick='layer.closeAll()'>取消</button>"
                +"</div>";
                layer.close(this.layerindex);
                this.layerindex = layer.open({
                      title:'封面选择',
                      type: 1,
                      skin: 'layui-layer-rim', //加上边框
                      area: ['650px', '460px'], //宽高
                      content: html,
                });
                
                //if(ueditorContent.imageUrl.length>ueditorContent.imageUrl.length)

                this.createImageBox($('#content_body'),this.getImageArray());
                //let migbox = 
            },
            //获取封面
            getImageArray(){
                var Url = [];
                let imageUrl = this.sumitContent.imageUrl;
                let otherImage = this.sumitContent.otherImage;
                
                for(var i in imageUrl){
                    Url.push(imageUrl[i]);
                }
                for(var j in otherImage){
                    Url.push(otherImage[j]);
                }

                return Url;
            },
            getContent(){
                let ueditorContent = this.getUeditorContent(this.instance,/static\/upload\/image\/[0-9]{24}/);
                this.sumitContent.content = ueditorContent.content;
                this.sumitContent.imageUrl = ueditorContent.imageUrl;
                this.sumitContent.imageName = ueditorContent.imageName;
                this.sumitContent.otherImage = ueditorContent.otherImage;

                console.log(this.getUeditorContent(this.instance,/static\/upload\/image\/[0-9]{24}/));
            }
        },
        components: {
          Ueditor
        },
        created(){
            
        }
    }
</script>
<style scoped>
    #editor{
        margin-top: 50px;
    }
    #article_title{
        border-top:1px solid #d4d4d4;
        border-left: 1px solid #d4d4d4;
        border-right: 1px solid #d4d4d4;
        border-bottom: none;
        outline: none;
        width: 100%;
        height: 50px;
        font-size: 18px;
        padding: 0px;
        padding-left: 5px; /*标题向内偏移*/
        color: #5B5B5B;
        /*font-weight: bold;*/
        letter-spacing: 3px;
    }
    #add_poster{
        display:inline-block;
        width:132px;
        height:88px;
        border:1px solid #ccc;
        line-height:88px;
        text-align: center;
        font-size: 50px;
        color: #A6A6A6;
    }
    #img_poster{
        display: none;
        border:1px solid #ccc;
        width:132px;
        height:88px;
        background-size: 132px 88px;
        margin-right: 20px;
        /*background: #cc0897;*/
        vertical-align: bottom;
        position: relative;
    }
    
</style>