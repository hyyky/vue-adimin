<template>
    <div id="Managerlist">
        <Row>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
            <Col span='20'>
                <span id="title">文章分类</span>
            </Col>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
        </Row>
        <br>
        <br>
        <Row :gutter='10'>
            
            <Col span="18">
                <div style="width:100%;display:inline-block"></div>
            </Col>
            <Col span='2' >
                <Button type="primary" long size='default' @click="addsort">
                <span style="vertical-align: text-bottom;">
                    <Icon type="md-add" size="15"/>
                </span>
                <span style="font-size:15px;margin-left:2px;">添加</span>
                </Button>
            </Col>
            <Col span='2'>
                <Button type="error" long size='default' @click="batchDelete">
                <span style="vertical-align: text-bottom;">
                    <Icon type="ios-trash" size="15"/>
                </span>
                <span style="font-size:15px;margin-left:2px;">删除</span>
                </Button>
            </Col>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
        </Row>
        <br>
        <Row>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
            <Col span='20'>
                <Table v-if="dataEmpty" width="888" border ref="selection" :columns="columns" :data="data"></Table>
                <Table v-else @on-select="getSelect" @on-select-all="getSelect" border ref="selection" @on-select-cancel="getSelect" @on-selection-change="getCacelSelect" :columns="columns" :data="data"></Table>
            </Col>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
        </Row>
        <br>
        <Row>
            <Col span="2">
                <div style="width:100%;display:inline-block"></div>
            </Col>
            <Page :total="total" :current="nowPage" show-elevator show-sizer @on-change="getArticlesortlist" show-total :page-size='number' @on-page-size-change="pageChange" :page-size-opts="pagelist"/>
        </Row>

        <Modal v-model="is_delete" width="288">
            <p slot="header" style="height:18px;color:#f60">
                <Icon type="ios-information-circle"></Icon>
                <span>提示</span>
            </p>
            <div style="text-align:center;font-size:18px;">
                <p>您确定要删除吗？</p>
            </div>
            <div slot="footer" id="logout">
                <Button type="default" @click="quitDelete">取消</Button>
                <Button type="primary" @click="deleteSuccess">确定</Button>
            </div>
        </Modal>
    </div>
</template>
<style scoped>
    #Managerlist{
        margin-top:66px;
    }
    #title{
        font-size: 18px;
    }
    td{
        width: auto;
    }
</style>
<script>
    export default {
        name: 'Articlesort',
        data () {
            return {
                columns: [
                    {
                        type: 'selection',
                        width: 50,
                        align: 'center'
                    },
                    {
                        title: '账号',
                        key: 'sort',
                        align: 'center'
                    },
                    {
                        title: '上级分类',
                        key: 'father',
                        align: 'center'
                    },
                    
                    {
                        title: '操作',
                        key: 'action',
                        width: 150,
                        align: 'center',
                        render:(h,args)=>{
                            return h('div',[
                                h('Button',{
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            console.log(args.row.id);
                                            this.edit(args.row.id)
                                        }
                                    }
                                },'编辑'),
                                h('Button',{
                                    props: {
                                        type: 'error',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.remove(args.row.id,args.index)
                                        }
                                    }
                                },'删除'),
                            ])
                        }
                    }
                ],
                data: [
                    
                ],
                is_delete:false,
                delete_index:'',
                delete_id:{id:''},
                getArticleSortUrl:'mapi/index/getArticlesortlist?a=1&list=1',//分类列表
                getsortUrl:'mapi/index/getArticlesortdata?ed=1',//一条管理员信息
                delArticlesortUrl:'mapi/index/delArticlesort?del=1',
                number:3,//每页数量
                nowPage:1,//当前页
                total:0,
                pagelist:[3,6,9,12],
                totalPage:0,
            }
        },
        computed:{
            dataEmpty:function(){
                if(this.isEmpty(this.data)){
                    return true;
                }
                return false;
            }
        },
        methods:{
            isEmpty:function(obj){
                for(var i in obj){
                    return false;
                }
                return true;
            },
            show (index) {
                this.$Modal.info({
                    title: 'User Info',
                    content: `分类名称：${this.data[index].sort}<br>父级分类：${this.data[index].father}`
                });
            },
            edit(id){
                var app = this;
                this.$post(this.getsortUrl,{
                    id:id,
                }).then(data=>{
                    console.log(data);
                    if(data.status=='error'){
                        switch(data.type){
                            case 'no_data':
                            app.$Message.warning('暂无数据!');
                            break;
                            case 'error_params':
                            app.$Message.warning('非法操作!');
                            break;
                            default:
                            break;
                        }
                        return;
                    }else if(data.status=='success'){
                        window.localStorage.setItem('articlesortedit',JSON.stringify(data.data));
                        window.location.href  = '/article/article_sort_edit';
                    }
                })
            },
            remove (id,index) {

                if(!id){
                    return;
                }

                this.delete_index = index;
                this.delete_id = {id:id};
                this.is_delete = true;
            },
            addsort(){
                window.location.href = '/article/article_sort_add';
            },
            deleteSuccess(){
                if(this.delete_id.id.length==0){
                    this.$Message.warning('请先选择要删除的项目!');
                }
                var app = this;
                this.is_delete = false;
                this.$post(this.delArticlesortUrl,this.delete_id)
                .then(data=>{
                    if(data.status == 'error'){
                        switch(data.type){
                            case 'no_data':
                            app.$Message.warning('分类不存在!');
                            break;
                            case 'no_delete':
                            app.$Message.warning('删除失败!');
                            break;
                            case 'error_params':
                            app.$Message.warning('非法操作!');
                            break;
                            case 'exit_data':
                            app.$Message.warning('该分类有文章，不可删除!');
                            break;
                            default:
                            break;
                        }
                        console.log(data);
                        return;
                    }else if(data.status=='success'){
                        var ids = this.delete_id.id;
                        var listdata = this.data;
                        if(typeof ids === 'object' && ids.length>0){
                            for(var i in ids){
                                for(var j in listdata){
                                    if(ids[i] == listdata[j].id){
                                        listdata.splice(j,1);
                                        this.total = this.total-1;
                                    }
                                }
                            }
                        }else{
                            listdata.splice(this.delete_index,1);
                            this.total = this.total-1;
                        }

                        setTimeout(function(){
                            app.$Message.success('删除成功!');
                            app.resetPageData();
                            app.getArticlesortlist();
                        },300);
                    }
                });
            },
            //重新设置当前页码数据
            resetPageData(){
                //获取当前总页数
                var totalPage = Math.ceil(this.total/this.number);
                this.totalPage = totalPage>0?totalPage:1;
                this.nowPage = this.nowPage>0?this.nowPage:1;

                if(this.nowPage>=this.totalPage)
                {   
                    this.nowPage = this.totalPage;
                    window.location.hash = 'p'+this.nowPage+'num'+this.number;
                }
            },
            
            quitDelete(){
                this.is_delete = false;
            },
            getSelect(selection){
                //console.log(selection);
                var ids = [];
                for(var i in selection){
                    if(selection[i] && selection[i].id)
                        ids.push(selection[i].id);
                }
                this.delete_id = {id:ids,json:true};
            },
            getCacelSelect(selection){
                console.log(selection);
                var ids = [];
                for(var i in selection){
                    if(selection[i] && selection[i].id)
                        ids.push(selection[i].id);
                }
                this.delete_id = {id:ids,json:true};
            },
            //批量删除
            batchDelete(){
                if(!this.delete_id.id ||this.delete_id.id==[] || this.delete_id.id.length==0){
                    this.$Message.warning('请先选择要删除的项目!');
                    return;
                }
                this.is_delete = true;
            },
            getArticlesortlist(page){
                if(page){
                    this.nowPage = page;
                    console.log(window.location.hash);
                    window.location.hash = 'p'+this.nowPage+'num'+this.number;
                }
                
                //因为缺少后端，所以先写死,暂时不写数据模型
                this.data = [
                    {
                        father: null,
                        id: 1,
                        pid: 0,
                        sort: "创业"
                    },

                    {
                        father: null,
                        id: 9,
                        pid: 2,
                        sort: "事件营销"
                    },

                    {
                        father: "创业",
                        id: 16,
                        pid: 1,
                        sort: "创业新闻"
                    }
                ];

                this.total = 3;
                return;

                this.$post(this.getArticleSortUrl,{
                    p:this.nowPage,
                    num:this.number
                })
                .then(data=>{
                    if(!data.status &&data.login==undefined){
                        console.log(data);
                        this.total = data.total;
                        this.data = data.data;
                        this.resetPageData();
                    }
                });
            },
            pageChange(number){
                this.number = number;
                window.location.hash = 'p'+this.nowPage+'num'+this.number;
                this.getArticlesortlist();
            }
        },
        created:function(){
            // 这里因为没有用vuex，暂时用访问地址获取分页信息，刷新不变，前提是在history模式，否则运行报错
            if(window.location.hash){
                var hash = window.location.hash.slice(1);
                this.nowPage = +(hash.match(/p\d+/)[0].match(/\d+/)[0]);
                this.number = +(hash.match(/num\d+/)[0].match(/\d+/)[0]);
            }
            this.getArticlesortlist();
            // this.$fetch(this.getArticleSortUrl)
            // .then(data=>{
            //     if(!data.status &&data.login==undefined){
            //         console.log(data);
            //         this.total = data.length;
            //         this.data = data;
            //     }
            // });
        }
    }
</script>
