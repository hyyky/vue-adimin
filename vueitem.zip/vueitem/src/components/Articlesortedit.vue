<template>
    <div id="container">
        <Row type="flex" justify="center">
            <Col span="10">
                <div id="title">
                    文章分类编辑
                </div>
            </Col>
        </Row>
        <br>
        <Row type="flex" justify="center">
            <Col span="10">
            <div id="Input">
                
                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    <span class="must">*</span>
                    分类名称：
                    </Col>
                    <Col span="18">
                    <Input type='text' id="username" placeholder="分类名称"  v-model="sortData.sort" style="width: 100%"/>
                    </Col>
                    </Row>
                </div>
                
                <br>

                <div class="Input_div">
                    <Row type="flex" align="middle">
                    <Col span="6">
                    上级分类：
                    </Col>
                    <Col span="18">
                    <Select  :filterable="true" :remote="true" @remote-method='getArticleSort' @on-query-change="setKeyword" :loading='false' style="width:100%" v-model="sortData.father" :label="sortData.father">
                        <Option :key="0" :value="0">顶级分类</Option>
                        <Option :key="sort.id" v-for="sort in classData" :value="sort.id">{{sort.sort}}</Option>
                    </Select>
                    </Col>
                    </Row>
                </div>

                <br>

                <div class="Input_div">
                    <Row type="flex" align="middle">
                        <Col span="6">
                            <div style="width:100%;display:inline-block"></div>
                        </Col>
                        <Col span="18">
                            <Button type="primary" long @click="eidtAticleClass">保存</Button>
                        </Col>
                    </Row>
                    
                </div>
            </div>
            </Col>
        </Row>
    </div>
</template>
<style scoped>
    #title{
        font-size: 20px;
        margin-top:60px;
    }
    #container{
    }

    #Input{
        margin-top:20px;
    }
    .Input_div{
        width: 300px;
    }
</style>
<script>
    export default {
        name:'Articlesortedit',
        data () {
            return {
                classData:[],
                sortData:{
                    id:0,
                    sort:'',
                    father:0,
                },
                edit_url:'/mapi/index/editArticlesort',
                search_url: '/mapi/index/addArticleClass?add=1',
                keyword:{
                    s:''
                },
            }
        },
        methods:{
            eidtAticleClass:function(){
                var app = this;
                if(this.sortData.sort==''){
                    this.$Message.warning('请输入分类名称');
                    return;
                }
                //console.log(this.sortData);return;
                //console.log(this.sortData);
                this.$post(this.edit_url,this.sortData)
                .then(data=>{
                    if(data.status=='error'){
                        switch(data.type){
                            case 'error_params':
                                app.$Message.warning('请求参数有误！');
                                break;
                            case 'empty_data':
                                app.$Message.warning('分类名称不能为空！');
                                break;
                            case 'exit_data':
                                app.$Message.warning('分类名称已存在！');
                                break;
                            case 'no_update':
                                app.$Message.warning('修改失败！');
                                break;
                            case 'no_change':
                                app.$Message.warning('数据未更改！');
                                break;
                            default:
                                break;
                        }
                    }else if(data.status=='success'){
                        console.log(data);
                        app.$Message.success('修改成功，正在跳转！');
                        setTimeout(function(){
                            window.localStorage.setItem('articlesortedit','');
                            window.location.href = '/article/article_sort';
                        },1500);
                    }
                });

            },
            getArticleSort(){
                
            },
            setKeyword(e){
                this.keyword.s = e;
                this.$post('/mapi/index/getArticlesort?a=1',this.keyword)
                .then(data=>{
                    console.log(data);
                    this.classData = data;
                })
                .catch(data=>{
                    console.log(data);
                });
            }
        },
        props:[],
        created:function(){
            this.$fetch('/mapi/index/getArticlesort?a=1')
            .then(data=>{
                this.classData = data;
                this.sortData = JSON.parse(window.localStorage.getItem('articlesortedit'));
                console.log(this.sortData);
            });
        }
    }
</script>
