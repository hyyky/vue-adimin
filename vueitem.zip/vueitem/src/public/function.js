
/**
 *  instance 表示ue实例；pathstring代表图片路径某些字符串，用于标识
 **/
export function getUeditorContent(instance,pathstring=''){

    var contentHtml = instance.getContent();
    contentHtml = contentHtml.replace(/(&nbsp;){2,}/g,'');//最少匹配2次，若只有一个，可以忽视
    contentHtml = contentHtml.replace(/<p>(\s)*(&nbsp;)*(\s)*(<br\/>)*<\/p>/g,'');
    
    if(pathstring){
        var imgs = contentHtml.match(/src=[\'\"]{1}[^\'\"<]+[\'\"]{1}/g);//提取图片地址
        var picUrl = new Object();
        var picName = new Object();
        var otherImage = new Object();
        if(imgs!==null){
            for(var i=0;i<imgs.length;i++){
                imgs[i] = imgs[i].replace(/(src=)*[\'\"]/g,'');//上传的图片和插入的网络图片
                if(pathstring.test(imgs[i]) == true){
                    picUrl[i] = imgs[i];//上传的图片位于网站的地址
                    picName[i] = imgs[i].substring(imgs[i].lastIndexOf('/')+1);//图片名称
                }else{
                    otherImage[i] = imgs[i];//其他图片
                }
            }
        }
        return {
            content:contentHtml,
            imageUrl:picUrl,
            imageName:picName,
            otherImage:otherImage
        }
    }

    //返回编辑器内容、图片路径和图片名称
    return {
        content:contentHtml,
        imageUrl:{},
        imageName:{},
        otherImage:{}
    }
}
//执行某个函数，funName表示函数名
export function execute(funName,Obj=null){
    if(typeof funName == 'function'){
        if(Obj)
        funName(Obj);
        else
        funName();
    }
}

export function removeElement(target,boo=false){
    if(!boo)
        $(target).remove();
    else
        $(target).parent().remove();
}