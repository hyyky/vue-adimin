import axios from 'axios';
import Qs from 'qs';
axios.defaults.timeout=5000;
axios.defaults.baseURL='http://192.168.5.129:8001/';

//import Promise from 'es6-promise'

// 添加请求拦截器
axios.interceptors.request.use(function (config) {
    // 在发送请求之前做些什么
    config.headers 	=	{
    	'Content-Type':'application/x-www-form-urlencoded',
    }
    if(config.data&&config.data.json){
        config.headers  =   {
            'Content-Type':'application/json',
        }
    }
    if(config.headers && !config.headers['x-token']){
        config.headers['x-token'] = window.localStorage.getItem('jwt');
    }
    if (config.headers['Content-Type'] == 'application/x-www-form-urlencoded') {
        if(config.data)
        config.data = Qs.stringify(config.data);
        /*if(config.params)
        config.params = Qs.stringify(config.params,{arrayFormat: 'brackets'});*/
    }
    return config;
  }, function (error) {
    // 对请求错误做些什么
    return Promise.reject(error);
  });

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
	// 对响应数据做点什么
	return response;
}, function (error) {
	// 对响应错误做点什么
	return Promise.reject(error);
});
  
//get请求
export function fetch(url,params={}) {
	return new Promise((resolve,reject)=>{
		axios.get(url,{
			params:params,
		}).then(response=>{
			resolve(response.data);
		}).catch(error=>{
			reject(error);
		});
	});
}

//post请求
export function post(url,data={}){
	return new Promise((resolve,reject)=>{
		axios.post(url,data)
		.then(response=>{
			resolve(response.data);
		})
		.catch(error=>{
			reject(error);
		});
	});
}

export function maxios(config={}){
    return new Promise((resolve,reject)=>{
        axios(config)
        .then(response=>{
            resolve(response.data);
        })
        .catch(error=>{
            reject(error);
        });
    })
}