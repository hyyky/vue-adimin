// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router/index'
import iView from 'iview'
import 'iview/dist/styles/iview.css';
import '../theme/index.less'
/*import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'*/

//axios请求
import {fetch,post,maxios} from './public/http'
import {getUeditorContent,execute,removeElement} from './public/function';
Vue.prototype.$fetch = fetch
Vue.prototype.$post = post
Vue.prototype.maxios = maxios
Vue.prototype.getUeditorContent = getUeditorContent
Vue.prototype.removeElement = removeElement

Vue.config.productionTip = false
Vue.use(iView)
//Vue.use(ElementUI)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>',
  //base: '/static/page/dist/', 
});
