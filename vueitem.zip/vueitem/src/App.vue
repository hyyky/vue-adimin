<template>
  <div id="app">
    <Layout v-if="login_status">
        <Header id="Header"><MyHeader @loginStatus="loginStatus"></MyHeader></Header>
        <Layout id="Layout">
            <Sider id="Sider" width="auto"><Navigation :setMenus="menus" :menusStyle="MenusStyle" ></Navigation></Sider>
            <Content id="Content"><router-view></router-view></Content>
        </Layout>
        <Footer id="Footer">Footer</Footer>
    </Layout>
    <div v-else-if="logout_status" id="login" ref='login'><Login  v-on:loginStatus="loginStatus"></Login></div>
    <div v-if="browerSuppor" id="brower_suppor">
        您的浏览器不支持！
        <div>
          <p>目前支持浏览器：</p>
          <p>IE9及以上，谷歌浏览器等现代浏览器</p>
        </div>
    </div>
  </div>
</template>
<script>
import Navigation from './components/Navigation'
import MyHeader from './components/MyHeader' 
import Login from './components/Login' 

export default {
  name: 'App',
  data () {
    return {
        MenusStyle:{
          color:'#000000',
          activeColor:'#c61ce3',
          background:'#fff',
          menusBackground:'#fff',
          activeBackground:'#fff',
          childBackground:'#fff',
          childActiveBackground:'#fff',
          childColor:'#000000',
          childActiveColor:'#c61ce3',
          divWidth:120,
          divMaxWidth:70,
          reqestUrl:'/mapi/index/getMenus?m=1',
        },
        menus:{

        },
        login_status:false,
        logout_status:false,
        browerSuppor:false,
    }
  },
  components:{
    Navigation,
    MyHeader,
    Login,
  },
  methods: {
      //接收子组件传值
      loginStatus: function (value) {
          this.login_status = value.login;
          this.menus = value.menus;
          if(window.localStorage){
              window.localStorage.setItem('jwt',value.token);
          }
          if(value.login){
              this.logout_status = false;
          }else{
              this.logout_status = true;
          }
      },
      createMenus:function(){
          
          var token = window.localStorage.getItem('jwt');
          //window.localStorage.setItem('jwt','');
          if(!token){
              this.login_status = false;
              this.logout_status = true;
              window.localStorage.setItem('menus','');
              return;
          }else{
              var config = {
                  method: 'get',
                  url: this.MenusStyle.reqestUrl,
              };
              this.maxios(config)
              .then(data=>{
                  
                  if(data.login){
                      this.menus = data.menus;
                      this.logout_status = false;
                      this.login_status = data.login;
                  }else{
                      
                      if(data.time_exp)
                        this.$Message.warning('账号过期，请重新登录!');
                      if(data.not_user)
                        this.$Message.warning('用户不存在或密码错误!');

                      setTimeout(function(){
                          window.location.href = '/';
                          this.logout_status = true;
                          this.login_status = data.login;
                      },1500);
                  }
                  if(data.token!==undefined){
                      window.localStorage.setItem('jwt',data.token);
                  }
              });
          }
      }
  },
  created:function(){
      if(!window.localStorage){
          this.browerSuppor = true;
          return;
      }
      if(navigator.userAgent.indexOf('Edge')>-1){
          this.browerSuppor = true;
          return;
      }
      this.createMenus();
  }
  
}



</script>
<style type="text/css" ></style>
<style type="text/css">

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  min-width: 1200px;
}
#Header{
  padding: 0px;
  height: auto;
}

#Layout{
  min-height: 450px;
}

#Sider{
  width: 13%;
  background: #fff;
}
#Col{
  display: inline-block;
}
#Content{
  padding-bottom: 88px;
}

#Footer{
  text-align: center;
  background: #fff;
}

#login{
    display: block;
    height: 100%;
    padding-bottom: 188px;
    background: #E6E6FA
}

/**
必填选项星号
**/
.must{
    color:red;
    position:absolute;
    left:-6px
}

.active{
    border:2px solid #00bfff;
}
  
</style>


