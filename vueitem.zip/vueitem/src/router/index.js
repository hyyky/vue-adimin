import Vue from 'vue'
import VueRouter from 'vue-router'
import App from '../App'
import HelloWorld from '../components/HelloWorld'
import header from '../components/header'
import Articlelist from '../components/Articlelist'
import Addmanage from '../components/Addmanage'
import Managerlist from '../components/Managerlist'
import Editmanage from '../components/Editmanage'
import Addarticle from '../components/Addarticle' 
import Articlesortadd from '../components/Articlesortadd'
import Articlesort from '../components/Articlesort'
import Articlesortedit from '../components/Articlesortedit'

Vue.use(VueRouter)

const router = new VueRouter({
  routes: [
  	{
      path: '/',
      name: 'App',
      App
    },
    {
      path: '/h',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/article/article_list',
      name: 'Articlelist',
      component: Articlelist
    },
    {
      path: '/article/article_add',
      name: 'Addarticle',
      component: Addarticle
    },
    {
      path: '/article/article_sort',
      name: 'Articlesort',
      component: Articlesort
    },
    {
      path: '/article/article_sort_edit',
      name: 'Articlesortedit',
      component: Articlesortedit
    },
    {
      path: '/article/article_sort_add',
      name: 'Articlesortadd',
      component: Articlesortadd
    },
    {
      path: '/manager/manager_add',
      name: 'Addmanage',
      component: Addmanage
    },
    {
      path: '/manager/manager_edit',
      name: 'Editmanage',
      component: Editmanage
    },
    {
      path: '/manager/manager_list',
      name: 'Managerlist',
      component: Managerlist
    },

    
  ],
  mode:'history',
  //base:'/static/page/dist/',

})
export default router

